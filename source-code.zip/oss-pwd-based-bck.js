const { Client } = require('@opensearch-project/opensearch');
const uuid = require('uuid');

// These should be set as environment variables
const OPENSEARCH_ENDPOINT = process.env.OPENSEARCH_ENDPOINT;
// const OPENSEARCH_ENDPOINT = "https://search-oss-domain-ua3lwtewy65h.us-east-1.es.amazonaws.com"
const opensearch = {
    async sendData(index, dataObject) {
        const client = new Client({
            node: OPENSEARCH_ENDPOINT,
            auth: {
                username: "<<your-username-here>>",
                password: "<<your-pwd-here>>"
            },
            ssl: {
                rejectUnauthorized: false // Only use this for testing. In production, use proper SSL certificates
            }
        });

        try {
            if (!(await client.indices.exists({ index })).body) {
                console.log((await client.indices.create({ index })).body);
            }

            const response = await client.index({
                id: uuid.v1(),
                index: index,
                body: dataObject,
            });

            console.log('Document indexed successfully:', response.body);
        } catch (error) {
            console.error('Error indexing document:', error);
        }
    }
};

module.exports = opensearch;

// await opensearch.sendData("idex1-fraser", {
//     "sample": "test"
// });    
