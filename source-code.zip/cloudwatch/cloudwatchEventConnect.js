const { CloudWatchClient, GetMetricDataCommand } = require("@aws-sdk/client-cloudwatch"); // CommonJS import
const region = process.env.AWS_REGION;
const client = new CloudWatchClient({ region: region });

const constants = require('../constants.js');
const date = require('date-and-time')

// Last 1 min data duration
const DATA_DURATION= 5;
const aoss = require('../oss.js');

const cloudwatchEventConnect = {
	async getData(ConnectInstanceId) {

    let endDate =  new Date();
    endDate.setMinutes(endDate.getMinutes() - DATA_DURATION);
    endDate.setSeconds(0);
    endDate.setMilliseconds(0)
    let startdate = new Date(endDate);
    startdate.setMinutes(endDate.getMinutes() - 1);

    let StartTime = startdate.toISOString();
    let EndTime = endDate.toISOString();
    console.log('StartTime', StartTime);
    console.log('EndTime', EndTime);

    let params = {};
    let MetricDataQueries = 
      [ 
        {
          'Id': 'metric_alias_metrics_view_graph_0', /* required */
          'Label': 'ConcurrentCalls',
          'MetricStat': {
            'Metric': { 
              'Dimensions': [
                {
                  "Name": "InstanceId",
                  "Value": ConnectInstanceId
                },
                {
                  "Name": "MetricGroup",
                  "Value": "VoiceCalls"
                }
              ],
              'MetricName': 'ConcurrentCalls',
              'Namespace': 'AWS/Connect'
            },
            'Period': '60', 
            'Stat': 'Maximum', 
          }
        },
        {
          'Id': 'metric_alias_metrics_view_graph_1', /* required */
          'Label': 'ConcurrentActiveChats',
          'MetricStat': {
            'Metric': { 
              'Dimensions': [
                {
                  "Name": "InstanceId",
                  "Value": ConnectInstanceId
                },
                {
                  "Name": "MetricGroup",
                  "Value": "Chats"
                }
              ],
              'MetricName': 'ConcurrentActiveChats',
              'Namespace': 'AWS/Connect'
            },
            'Period': '60', 
            'Stat': 'Maximum', 
          }
        },
        {
          'Id': 'metric_alias_metrics_view_graph_2', /* required */
          'Label': 'ConcurrentTasks',
          'MetricStat': {
            'Metric': { 
              'Dimensions': [
                {
                  "Name": "InstanceId",
                  "Value": ConnectInstanceId
                },
                {
                  "Name": "MetricGroup",
                  "Value": "Tasks"
                }
              ],
              'MetricName': 'ConcurrentTasks',
              'Namespace': 'AWS/Connect'
            },
            'Period': '60', 
            'Stat': 'Maximum', 
          }
        },  
        {
          'Id': 'metric_alias_metrics_view_graph_3', /* required */
          'Label': 'ThrottledCalls',
          'MetricStat': {
            'Metric': { 
              'Dimensions': [
                {
                  "Name": "InstanceId",
                  "Value": ConnectInstanceId
                },
                {
                  "Name": "MetricGroup",
                  "Value": "VoiceCalls"
                }
              ],
              'MetricName': 'ThrottledCalls',
              'Namespace': 'AWS/Connect'
            },
            'Period': '60', 
            'Stat': 'Sum', 
          }
        },
        {
          'Id': 'metric_alias_metrics_view_graph_4', /* required */
          'Label': 'MissedCalls',
          'MetricStat': {
            'Metric': { 
              'Dimensions': [
                {
                  "Name": "InstanceId",
                  "Value": ConnectInstanceId
                },
                {
                  "Name": "MetricGroup",
                  "Value": "VoiceCalls"
                }
              ],
              'MetricName': 'MissedCalls',
              'Namespace': 'AWS/Connect'
            },
            'Period': '60', 
            'Stat': 'Sum', 
          }
        }
      ];

    params.MetricDataQueries = MetricDataQueries;
    params.EndTime = endDate;
    params.StartTime = startdate;
    
    const command = new GetMetricDataCommand(params);

    let response = await client.send(command);

    console.log('response', JSON.stringify(response));

    let datetime = new Date().toISOString();

    const indexName = getIndexName();
    let outputObj ={};
    let recordFound = false;

    outputObj.EventTimestamp = datetime;
    if (response && response.MetricDataResults) {
      for (let index = 0; index < response.MetricDataResults.length; index++) {
    
        const record = response.MetricDataResults[index];
        
        if (record.Timestamps && record.Values && record.Values.length > 0) {
          recordFound = true;
          outputObj[record.Label] =  record.Values[0];
        }
        else{
          // Dont send anything if nothing comes back
          // outputObj[record.Label] =  0;
        }

        if(record.Timestamps && record.Timestamps.length>0){
          outputObj.EventTimestamp = record.Timestamps[0];
        }
    }
    if(recordFound){
      console.log('outputObj', JSON.stringify(outputObj));
      await aoss.sendData(indexName, outputObj);
    }else{
      console.log('no data to send to Open Search');
    }

    }
  }
}

function getIndexName(){
  let todayDate = new Date().toISOString().slice(0, 10);
  return constants.concurrent + todayDate;

}

module.exports = cloudwatchEventConnect;
