const opensearch = require('./oss.js');
exports.handler = async function handler() {
  await opensearch.sendData('test-index-1', { message: 'Hello, OpenSearch!' });
}
