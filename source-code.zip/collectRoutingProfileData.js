const { defaultProvider } = require('@aws-sdk/credential-provider-node');
const { Client } = require('@opensearch-project/opensearch');
const { AwsSigv4Signer } = require('@opensearch-project/opensearch/aws');
const currentMetricDataFunction = require('./currentMetricDataFunction.js');
const routingProfileList = require('./routingProfileList.js');
const aoss = require('./oss.js');
const constants = require('./constants.js');

const ConnectInstanceId = process.env.ConnectInstanceId;

const collectRoutingProfileData = {
    async getByGroup(routingProfileArray, routingProfileNames) {
        let todayDate = new Date().toISOString().slice(0, 10);

        let routingProfileCurrentMetricOutput = await currentMetricDataFunction.getCurrentMetricDataGroupByRoutingProfile(ConnectInstanceId, constants.channels, routingProfileArray);
    
        let routingProfileCurrentMetricOutputFormatted = await currentMetricDataFunction.parsePostRoutingProfileOutput(routingProfileCurrentMetricOutput,routingProfileNames,todayDate);
    }
}
module.exports = collectRoutingProfileData;