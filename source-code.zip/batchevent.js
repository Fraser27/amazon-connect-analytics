const collectQueueData = require('./collectQueueData.js');
const collectRoutingProfileData = require('./collectRoutingProfileData.js');
const collectMetricDataV2 = require('./collectMetricDataV2.js');
const aossDataCache = require('./dynamodb/aossDataCache.js');
const loadCacheData = require('./loadCacheData.js');

const ConnectInstanceId = process.env.ConnectInstanceId;

exports.handler = async function (event, context, callback) {
    //console.log("INPUT -  ", JSON.stringify(event));
    
    let startTime = Date.now();
    console.log('startTime', startTime)
    let loopCount = 0;

    let result = {};
    do {

    // Collect and send Queue Data to Open Search
    let queueArray = await aossDataCache.query('queueArray');
    let queueNames = await aossDataCache.query('queueNames');
    
    // Collect and send Routing Profile Data to Open Search
    let routingProfileArray = await aossDataCache.query('routingProfileArray');
    let routingProfileNames = await aossDataCache.query('routingProfileNames');

    if(!queueArray && !routingProfileArray){
        // LOAD CACHE DATA
        console.log('EMPTY CACHE , LOAD QUEUE & ROUTING INFO');
        await loadCacheData.getData(ConnectInstanceId);

        queueArray = await aossDataCache.query('queueArray');
        queueNames = await aossDataCache.query('queueNames');
    
        routingProfileArray = await aossDataCache.query('routingProfileArray');
        routingProfileNames = await aossDataCache.query('routingProfileNames');        
    }

    await collectQueueData.get(queueArray, queueNames);
    await collectQueueData.getByGroup(queueArray, queueNames);

    await collectRoutingProfileData.getByGroup(routingProfileArray, routingProfileNames);

    await collectMetricDataV2.get(ConnectInstanceId, queueArray, 5);

    await sleep(15000);

    let timelapsed = (Date.now()-startTime) / 1000;
    console.log('timelapsed',timelapsed)
    if(timelapsed > 105){
      break;
    }    
    loopCount++;

    } while (loopCount < 8);

    callback(null, result);
};

function sleep(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  }