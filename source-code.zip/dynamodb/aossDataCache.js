
const { DynamoDBClient, PutItemCommand, UpdateItemCommand, QueryCommand, ScanCommand} = require("@aws-sdk/client-dynamodb");
const aossDataCacheTable = process.env.AOSSDataCacheTable;

const client = new DynamoDBClient({});

const aossDataCache = {
  async saveInfo(keyId, keyData) {
    try {
      let paramsIns = {
        TableName: aossDataCacheTable,
        Item: {
          keyId: { S: keyId },
          keyData: { S: keyData },
          eventTime: { S: (new Date().toISOString()) },
        },
      };
      const command = new PutItemCommand(paramsIns);
      const response = await client.send(command);
    } catch (error) {
      console.log(error);
    }
  },
  async query(keyId) {
    let queryOutput;
    try {
      let paramsIns = {
        TableName: aossDataCacheTable,
        KeyConditionExpression: "keyId = :keyId",
        ExpressionAttributeValues: {
          ":keyId": { S: keyId },
        },
      };
      const command = new QueryCommand(paramsIns);
      const response = await client.send(command);
      
      if(response && response.Items && response.Items.length>0 && response.Items[0].keyData && response.Items[0].keyData.S){
        queryOutput = JSON.parse(response.Items[0].keyData.S);
      }
    } catch (error) {
      console.log(error);
    }
    return queryOutput;
  }
};
module.exports = aossDataCache;
