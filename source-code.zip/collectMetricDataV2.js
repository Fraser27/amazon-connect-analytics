const getMetricDataV2 = require('./connect/getMetricDataV2.js');
const aoss = require("./oss.js");
const constants = require('./constants.js');

const collectMetricDataV2 = {
    async get(instanceId, queueArray, hoursData) {
      let todayDate = new Date().toISOString().slice(0, 10);

        let response = await getMetricDataV2.getData(instanceId, queueArray, hoursData);

        let datetime = new Date().toISOString();
        let outputObj = {};
        if (response && response.MetricResults && response.MetricResults[0] && response.MetricResults[0].Collections) {
          for (const metricResultCollection of response.MetricResults[0].Collections) {
            outputObj[metricResultCollection.Metric.Name] =  metricResultCollection.Value;
          }
        }
    
        outputObj.EventTimestamp = datetime;
  
        const indexName = constants.getMetricIndex + todayDate;
        await aoss.sendData(indexName, outputObj);
    }
}
module.exports = collectMetricDataV2;