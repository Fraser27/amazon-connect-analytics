const cloudwatchEventConnect = require("./cloudwatch/cloudwatchEventConnect.js");

const ConnectInstanceId = process.env.ConnectInstanceId;

exports.handler = async function (event, context, callback) {
  //console.log("INPUT -  ", JSON.stringify(event));
  let result = {};

  // Get Metric Data
  await cloudwatchEventConnect.getData(ConnectInstanceId);

  // Sleep 15 seconds
  await sleep(15000);

  // Get Metric Data
  await cloudwatchEventConnect.getData(ConnectInstanceId);

  callback(null, result);
};

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}
