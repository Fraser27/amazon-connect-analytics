const { Client } = require('@opensearch-project/opensearch');
const { AwsSigv4Signer } = require('@opensearch-project/opensearch/aws');
const { defaultProvider } = require('@aws-sdk/credential-provider-node');
const uuid = require('uuid');

// This should be set as an environment variable
const OPENSEARCH_ENDPOINT = process.env.OPENSEARCH_ENDPOINT;
const opensearch = {
    async sendData(index, dataObject) {
        const client = new Client({
            ...AwsSigv4Signer({
                region: process.env.AWS_REGION,
                service: 'es',
                getCredentials: () => defaultProvider()(),
            }),
            node: OPENSEARCH_ENDPOINT
        });

        try {
            if (!(await client.indices.exists({ index })).body) {
                console.log((await client.indices.create({ index })).body);
            }

            const response = await client.index({
                id: uuid.v1(),
                index: index,
                body: dataObject,
            });

            console.log('Document indexed successfully:', response.body);
        } catch (error) {
            console.error('Error indexing document:', error);
        }
    }
};

module.exports = opensearch;
