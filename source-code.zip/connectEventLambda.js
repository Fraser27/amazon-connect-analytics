const aoss = require("./oss.js");
const constants = require('./constants.js');

exports.handler = async function (event, context, callback) {
  //console.log("INPUT -  ", JSON.stringify(event));
  let result = {};

  try {
    if(event){
      if(event.time){
        event.EventTimestamp =event.time;
      }

      let todayDate = new Date().toISOString().slice(0, 10);
      const indexName = constants.contactEventStream + todayDate;

      await aoss.sendData(indexName, event);
    }
  } catch (error) {
    console.error("error", error);
  }

  callback(null, result);
};
