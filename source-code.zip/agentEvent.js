const aoss = require("./oss.js");
const constants = require('./constants.js');

exports.handler = async function (event, context, callback) {
//  console.log("INPUT -  ", JSON.stringify(event));
  let result = {};

  try {
    for (let i = 0; i < event.Records.length; i++) {
      let kinesisData = JSON.parse(
        Buffer.from(event.Records[i].kinesis.data, "base64").toString("ascii")
      );
      
      // console.log(kinesisData);

      let todayDate = new Date().toISOString().slice(0, 10);
      const indexName = constants.agentEventStream + todayDate;

      await aoss.sendData(indexName, kinesisData);
    }
  } catch (error) {
    console.error("error", error);
  }

  callback(null, result);
};
