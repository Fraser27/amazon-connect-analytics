
let loadCacheData = require('./loadCacheData.js');
const ConnectInstanceId = process.env.ConnectInstanceId;

exports.handler = async function (event, context, callback) {
    //console.log("INPUT -  ", JSON.stringify(event));
    let result = {};

    // LOAD CACHE DATA
    await loadCacheData.getData(ConnectInstanceId);

    callback(null, result);
};
