
const routingProfileList = require('./routingProfileList.js');
const queueList = require('./queueList.js');
const aossDataCache = require('./dynamodb/aossDataCache.js');

const loadCacheData = {
	async getData(ConnectInstanceId) {
        let queueListOutput = await queueList.getList(ConnectInstanceId);
        let queueArray = await queueList.getQueueArray(queueListOutput);
        let queueNames = await queueList.getQueueNameArray(queueListOutput);
    
        await aossDataCache.saveInfo('queueListOutput', JSON.stringify(queueListOutput));
        await aossDataCache.saveInfo('queueArray', JSON.stringify(queueArray));
        await aossDataCache.saveInfo('queueNames', JSON.stringify(queueNames));
    
        // Collect and send Routing Profile Data to Open Search
        let routingProfileListOutput = await routingProfileList.get(ConnectInstanceId);
        let routingProfileArray = await routingProfileList.getRoutingProfileArray(routingProfileListOutput);
        let routingProfileNames = await routingProfileList.getRoutingProfileNames(routingProfileListOutput);
    
        await aossDataCache.saveInfo('routingProfileListOutput', JSON.stringify(routingProfileListOutput));
        await aossDataCache.saveInfo('routingProfileArray', JSON.stringify(routingProfileArray));
        await aossDataCache.saveInfo('routingProfileNames', JSON.stringify(routingProfileNames));
    
    }
}

module.exports = loadCacheData;
